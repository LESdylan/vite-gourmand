
  # vite&gourmand

  This is a code bundle for vite&gourmand. The original project is available at https://www.figma.com/design/PLqIwVDMomecLLIKg0tqg6/vite-gourmand.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  