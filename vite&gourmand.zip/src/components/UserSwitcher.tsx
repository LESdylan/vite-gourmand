// This file has been replaced by QuickUserSwitcher.tsx
// Keeping this file temporarily to prevent cache errors
// Please use QuickUserSwitcher instead

import QuickUserSwitcher from './QuickUserSwitcher';

export default QuickUserSwitcher;
