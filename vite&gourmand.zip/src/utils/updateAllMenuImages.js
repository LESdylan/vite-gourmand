// Script pour mettre à jour toutes les images des menus
// Utilisez ce mapping pour les remplacements

const imageMapping = {
  "'business corporate menu'": "menuImages['m007']",
  "'business lunch menu'": "menuImages['m008']",
  "'networking cocktail menu'": "menuImages['m009']",
  "'birthday party menu'": "menuImages['m010']",
  "'kids birthday menu'": "menuImages['m011']",
  "'surprise birthday menu'": "menuImages['m012']",
  "'gourmet vegetarian menu'": "menuImages['m013']",
  "'seasonal vegetable menu'": "menuImages['m014']",
  "'balanced vegetarian menu'": "menuImages['m015']",
  "'gourmet vegan menu'": "menuImages['m016']",
  "'world vegan cuisine'": "menuImages['m017']",
  "'creative vegan menu'": "menuImages['m018']",
  "'southwest france terroir'": "menuImages['m019']",
  "'perigord regional menu'": "menuImages['m020']",
  "'ocean seafood menu'": "menuImages['m021']",
  "'fisherman gourmet menu'": "menuImages['m022']",
  "'spring seasonal menu'": "menuImages['m023']",
  "'summer mediterranean menu'": "menuImages['m024']",
  "'autumn seasonal menu'": "menuImages['m025']",
  "'winter comfort menu'": "menuImages['m026']",
  "'chic cocktail party'": "menuImages['m027']",
  "'gourmet aperitif'": "menuImages['m028']",
  "'bordeaux brunch menu'": "menuImages['m029']",
  "'healthy brunch menu'": "menuImages['m030']",
  "'prestige buffet catering'": "menuImages['m031']",
  "'country buffet rustic'": "menuImages['m032']",
  "'express lunch menu'": "menuImages['m033']",
  "'gourmet lunch menu'": "menuImages['m034']",
  "'romantic dinner menu'": "menuImages['m035']",
  "'friends dinner party'": "menuImages['m036']",
  "'culinary journey tasting'": "menuImages['m037']",
  "'world flavors menu'": "menuImages['m038']",
  "'new year celebration menu'": "menuImages['m039']",
  "'christmas traditional menu'": "menuImages['m040']",
  "'detox healthy menu'": "menuImages['m041']",
  "'sport protein menu'": "menuImages['m042']",
  "'gluten free menu'": "menuImages['m043']",
  "'lactose free menu'": "menuImages['m044']",
  "'student budget menu'": "menuImages['m045']",
  "'family budget menu'": "menuImages['m046']",
  "'absolute excellence premium'": "menuImages['m047']",
  "'luxury refined dining'": "menuImages['m048']",
  "'halal gourmet menu'": "menuImages['m049']",
  "'kosher elegant menu'": "menuImages['m050']"
};

// Pour l'utiliser dans la console Node.js:
// const fs = require('fs');
// let content = fs.readFileSync('/data/menus.ts', 'utf8');
// Object.entries(imageMapping).forEach(([old, new_]) => {
//   content = content.replace(new RegExp(old, 'g'), new_);
// });
// fs.writeFileSync('/data/menus.ts', content);

console.log('Image mapping ready!');
console.log(`Total replacements needed: ${Object.keys(imageMapping).length}`);
